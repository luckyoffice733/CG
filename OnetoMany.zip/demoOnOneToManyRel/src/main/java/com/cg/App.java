package com.cg;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.entity.Card;
import com.cg.entity.Customer;

public class App 
{
    public static void main( String[] args )
    {
        
    	Configuration cfg = new Configuration();
    	cfg.configure();
    	SessionFactory sfty=cfg.buildSessionFactory();
    	Session sion=sfty.openSession();
    	Transaction tx = sion.beginTransaction();
    	
    	Card cd1 = new Card();
    	cd1.setCardId(12346);
    	cd1.setCardNumber("234567456783");
    	LocalDate expDate =LocalDate.parse("2023-04-23");
    	cd1.setExpiryDate(expDate);
    	
    	sion.persist(cd1);
    	
    	Card cd2 = new Card();
    	cd2.setCardId(12347);
    	cd2.setCardNumber("765436575087");
    	LocalDate expDate2 =LocalDate.parse("2021-06-15");
    	cd2.setExpiryDate(expDate2);
    	
    	sion.persist(cd2);
    	
    	Customer c1 = new Customer();
    	c1.setCustomerId(1001);
    	c1.setName("James Butt");
    	c1.setEmailId("James@cg.com");
    	LocalDate dob =LocalDate.parse("1990-03-21");
    	c1.setDateOfBirth(dob);
    	
    	List<Card> lscd = new ArrayList<>();
    	lscd.add(cd1);
    	lscd.add(cd2);
    	
    	c1.setCard(lscd);
    	
    
    	sion.persist(c1);
    	
    	
    	
    	
    	
    	
   
    	tx.commit();
    	sion.close();
    }
}
