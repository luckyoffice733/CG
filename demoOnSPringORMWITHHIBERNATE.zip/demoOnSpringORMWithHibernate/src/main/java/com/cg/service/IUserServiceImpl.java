package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.IUserDao;
import com.cg.entity.User;

@Service
public class IUserServiceImpl implements IUserService{
	@Autowired
	private IUserDao  userDao; //has-a relation

	@Override
	@Transactional
	public int save(User user) {
		// TODO Auto-generated method stub
		return userDao.save(user);
	}

	@Override
	@Transactional
	public void update(User user) {
		// TODO Auto-generated method stub
		userDao.update(user);
	}

	@Override
	@Transactional
	public void delete(int userId) {
		// TODO Auto-generated method stub
		userDao.delete(userId);
	}

	@Override
	@Transactional(readOnly = true)
	public User getUserById(int userId) {
		// TODO Auto-generated method stub
		return  userDao.getUserById(userId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userDao.getAllUsers();
	}

}
