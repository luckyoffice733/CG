package com.cg.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cg.entity.User;
@Repository
public class IUserDaoImpl implements IUserDao{
	
	@Autowired
	private HibernateTemplate hTemplate;

	@Override
	public int save(User user) {
		// TODO Auto-generated method stub
		hTemplate.save(user);
		return user.getUserId();
	}

	@Override
	public void update(User user) {
		// TODO Auto-generated method stub
	    hTemplate.update(user);
	}

	@Override
	public void delete(int userId) {
		// TODO Auto-generated method stub
		User u =new User();
		u.setUserId(userId);
		hTemplate.delete(u);
	}

	@Override
	public User getUserById(int userId) {

		User user = hTemplate.get(User.class, userId);
		return user;

	}

	@Override
	public List<User> getAllUsers() {
		List<User> user = hTemplate.loadAll(User.class);
		return user;
	}

}
