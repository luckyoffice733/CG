package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EmployeeController {
	
	@RequestMapping("/show")  //http://localhost:8000/demoOnSpringWebMVC/mvc/show
	public String showMsg() {
		return "insert";   //it will search for insert.jsp in 
	}

}
