package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.User;

@Controller
@RequestMapping("/user")
public class UserController {

	@RequestMapping("/show")  //http://localhost:8000/projectName/mvc/user/show
	public ModelAndView showOutput() {
	ModelAndView mav = new ModelAndView();
	mav.setViewName("home"); //it willsearch for home.jsp
	User u = new User();
	u.setUserId(1001);
	u.setUserName("martin");
	u.setUserCode("#2121N");
	
	mav.addObject("data" ,u);
	return mav;
	}
	
}
