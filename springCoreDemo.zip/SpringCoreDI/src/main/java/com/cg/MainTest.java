package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;

public class MainTest {
   // ApplicationContext  ---> will act as spring container
	public static void main(String[] args) {
		
      ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Employee e =  context.getBean("emp",Employee.class);
		
		System.out.println("Employee Details are :");
		System.out.println(e.getEmpId()+" "+e.getEmpName()+" "+e.getEmpSal());
		
		
	}
	
}
