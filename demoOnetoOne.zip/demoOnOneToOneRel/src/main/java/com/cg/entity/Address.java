package com.cg.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity    //target
public class Address { //-->    //ORM MAPPING --> DB(table) //Address(address_id,street,city)
    @Id
	private Long addressId;
    
    @Column(length = 30)
	private String street;
    
    @Column(length = 20)
	private String city;

	public Long getAddressId() {
		return addressId;
	}

	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

    

}
