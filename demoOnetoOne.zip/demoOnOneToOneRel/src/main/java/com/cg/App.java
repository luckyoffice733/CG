package com.cg;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.entity.Address;
import com.cg.entity.Customer;

public class App 
{
    public static void main( String[] args )
    {
    	
      Configuration cfg = new Configuration();
      cfg.configure();
      
    SessionFactory sfty=  cfg.buildSessionFactory();
   Session sion= 	sfty.openSession();
   Transaction tx = sion.beginTransaction();
    	Address a1 =  new Address();
    	a1.setAddressId(101L);
    	a1.setStreet("720 Rockland Road");
    	a1.setCity("Losvegas");
    	
    	sion.persist(a1); //store in address table
    	
    	Customer cobj = new Customer();
    	cobj.setName("Williams");
    	cobj.setEmailId("williams01@cg.com");
    	
    	LocalDate d = LocalDate.parse("1979-06-03");
    	cobj.setDateOfBirth(d);
    	cobj.setAddress(a1);
        
    	sion.persist(cobj);
    	
    	
    	tx.commit();
    }
}
