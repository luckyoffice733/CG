package com.cg.bean;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component("impl2")
public class MyTestImpl2 implements MyTest{

	@Override
	public String getMessage(String msg) {
		// TODO Auto-generated method stub
		return "weclome in impl2 "+msg;
	}

}
